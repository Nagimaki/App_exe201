package com.example.det

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
